import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class ResultPage extends StatefulWidget {
  @override
  _ResultPageState createState() => _ResultPageState();
}

class _ResultPageState extends State<ResultPage> {
  final _nameController = TextEditingController();
  final _enrollmentController = TextEditingController();

  Future<void> _openResultSite() async {
    final name = _nameController.text;
    final enrollment = _enrollmentController.text;

    final url = Uri.parse(
        "https://www.ipuranklist.com/ranklist/btech/results?name=$name&enroll=$enrollment");

    if (await canLaunchUrl(url)) {
      await launchUrl(url, mode: LaunchMode.externalApplication);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Could not open result website")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Check Result")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _nameController,
              decoration: InputDecoration(labelText: "Enter Name"),
            ),
            TextField(
              controller: _enrollmentController,
              decoration: InputDecoration(labelText: "Enter Enrollment Number"),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _openResultSite,
              child: Text("View Result"),
            ),
          ],
        ),
      ),
    );
  }
}
