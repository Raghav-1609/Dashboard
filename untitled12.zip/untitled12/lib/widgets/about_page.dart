import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'dashboard_page.dart';

class AboutPage extends StatelessWidget {
  final Uri _vipsUrl = Uri.parse("https://vips.edu/");

  Future<void> _openWebsite() async {
    if (await canLaunchUrl(_vipsUrl)) {
      await launchUrl(_vipsUrl, mode: LaunchMode.externalApplication);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        fit: StackFit.expand,
        children: [
          Image.asset('assets/img.png', fit: BoxFit.cover),
          Container(color: Colors.black.withOpacity(0.5)),

          SingleChildScrollView(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              children: [
                SizedBox(height: 50),

                Card(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20),
                  ),
                  elevation: 8,
                  color: Colors.white.withOpacity(0.9),
                  child: Padding(
                    padding: const EdgeInsets.all(20.0),
                    child: Column(
                      children: [
                        Text(
                          "About Vivekananda Institute of Professional Studies (VIPS)",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                            color: Colors.black87,
                          ),
                        ),
                        SizedBox(height: 15),
                        Text(
                          "Vivekananda Institute of Professional Studies (VIPS), Pitampura, "
                              "is a premier institution affiliated to Guru Gobind Singh Indraprastha University (GGSIPU), "
                              "New Delhi. Established with a vision inspired by the ideals of Swami Vivekananda, VIPS "
                              "offers a diverse range of professional courses in Law, Business Administration, Journalism, "
                              "Computer Applications, and more.\n\n"
                              "The institute is known for its modern infrastructure, highly qualified faculty, strong "
                              "industry connections, and vibrant student life. VIPS emphasizes holistic development, "
                              "fostering leadership, innovation, and ethical values in students.\n\n"
                              "For detailed information on courses, admission process, notices, and campus life, "
                              "you can visit the official VIPS website below.",
                          textAlign: TextAlign.justify,
                          style: TextStyle(fontSize: 16, height: 1.5),
                        ),
                      ],
                    ),
                  ),
                ),

                SizedBox(height: 30),

                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    padding: EdgeInsets.symmetric(horizontal: 32, vertical: 14),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30),
                    ),
                  ),
                  onPressed: _openWebsite,
                  child: Text(
                    "Visit VIPS Official Website",
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                  ),
                ),

                SizedBox(height: 20),

                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.deepPurple,
                    padding: EdgeInsets.symmetric(horizontal: 32, vertical: 14),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30),
                    ),
                  ),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => DashboardPage()),
                    );
                  },
                  child: Text(
                    "Continue to Dashboard",
                    style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: Colors.yellow),
                  ),
                ),

                SizedBox(height: 50),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
