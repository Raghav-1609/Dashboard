import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../widgets/compact_button.dart';
import '../pages/result_page.dart';

class DashboardPage extends StatelessWidget {
  Future<void> _openWebsite(String url, BuildContext context) async {
    final uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Could not open $url")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [Colors.deepPurple.shade800, Colors.pink.shade600],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
          ),
          Opacity(
            opacity: 0.15,
            child: Image.asset(
              'assets/img.png',
              fit: BoxFit.cover,
              width: double.infinity,
              height: double.infinity,
            ),
          ),

          SafeArea(
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(20.0),
                  child: Text(
                    "VSET Dashboard",
                    style: TextStyle(
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                      letterSpacing: 1.5,
                      shadows: [
                        Shadow(
                          blurRadius: 8,
                          color: Colors.black45,
                          offset: Offset(2, 2),
                        )
                      ],
                    ),
                  ),
                ),

                Expanded(
                  child: Center(
                    child: GridView.count(
                      shrinkWrap: true,
                      crossAxisCount: 2,
                      mainAxisSpacing: 25,
                      crossAxisSpacing: 25,
                      padding: EdgeInsets.all(20),
                      children: [
                        CompactButton(
                          label: "Syllabus",
                          icon: Icons.menu_book,
                          onPressed: () => _openWebsite(
                            "https://firebasestorage.googleapis.com/v0/b/vips-website-88a23.appspot.com/o/VSET%2FSyllabus%2F1st%20year%20common%20syllabus%20with%20Bridge%20classes.pdf?alt=media&token=4956f858-58e6-4216-99a0-a448c94f33ac",
                            context,
                          ),
                        ),
                        CompactButton(
                          label: "Result",
                          icon: Icons.school,
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(builder: (_) => ResultPage()),
                            );
                          },
                        ),
                        CompactButton(
                          label: "Courses",
                          icon: Icons.book,
                          onPressed: () async {
                            final Uri url = Uri.parse(
                                "https://vips.edu/admissions/Programmes_Offered");
                            if (await canLaunchUrl(url)) {
                              await launchUrl(url,
                                  mode: LaunchMode.externalApplication);
                            }
                          },
                        ),
                        CompactButton(
                          label: "Fees",
                          icon: Icons.currency_rupee,
                          onPressed: () => _openWebsite(
                            "http://www.ipu.ac.in/pubinfo2024/nt300424548%20(2).pdf",
                            context,
                          ),
                        ),
                        CompactButton(
                          label: "Alumni",
                          icon: Icons.people,
                          onPressed: () => _openWebsite(
                            "https://vips.edu/Alumni_Meet",
                            context,
                          ),
                        ),
                        CompactButton(
                          label: "Time Table",
                          icon: Icons.access_time,
                          onPressed: () => _openWebsite(
                            "https://firebasestorage.googleapis.com/v0/b/vips-website-88a23.appspot.com/o/VSET%2FTimeTable%2F1st%20semester.pdf?alt=media&token=728224c7-dcdf-473f-95c6-417791d9803a",
                            context,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
